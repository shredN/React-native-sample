import React, { useEffect, useState, useContext } from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';

import { CartContext } from '../context/CartContext';

export function Cart({ navigation }) {

    const { items, getItemsCount, getTotalPrice, removeItemFromCart, addItemToCart } = useContext(CartContext);


    function Totals() {
        let [total, setTotal] = useState(0);
        useEffect(() => {
            setTotal(getTotalPrice());
        });
        return (
            <View style={styles.cartLineTotal}>
                <Text style={[styles.lineLeft, styles.lineTotal]}>Total</Text>
                <Text style={styles.lineRight}>$ {total}</Text>
            </View>
        );
    }

    function renderItem({ item }) {

        function onAddToCart() {
            addItemToCart(item.id);
        }

        function onRmFrmCart() {
            removeItemFromCart(item.id);
        }

        return (
            item.qty !== 0 && (
                <View style={styles.cartLine} >
                    <Text style={styles.lineLeft}>{item.product.productName}
                    </Text>
                    <View {...styles.addRemoveOption}>
                        <Text style={styles.lineLeft}>
                            <Button
                                onPress={onRmFrmCart}
                                title="-"
                                color='orange'
                                accessibilityLabel="remove from cart" />
                            {item.qty}
                            <Button
                                onPress={onAddToCart}
                                title="+"
                                color='orange'
                                accessibilityLabel="remove from cart" />
                        </Text>
                    </View>
                    <Text style={styles.lineRight}>$ {item.totalPrice}</Text>
                </View>)
        );
    }

    return (
        <FlatList
            style={styles.itemsList}
            contentContainerStyle={styles.itemsListContainer}
            data={items}
            renderItem={renderItem}
            keyExtractor={(item) => item.product.id.toString()}
            ListFooterComponent={Totals}
        />
    );
}

const styles = StyleSheet.create({
    cartLine: {
        flexDirection: 'row',
        justifyContent: 'space-around'
    },
    cartLineTotal: {
        flexDirection: 'row',
        borderTopColor: '#dddddd',
        borderTopWidth: 1
    },
    lineTotal: {
        fontWeight: 'bold',
    },
    addRemoveOption: {
        flex: 1,
        flexDirection: 'row',
        justifyContent: 'center',
    },
    lineLeft: {
        fontSize: 20,
        lineHeight: 40,
        color: '#333333'
    },
    button: {
        backgroundColor: '#DDDDDD',
    },
    lineRight: {
        flex: 1,
        fontSize: 20,
        fontWeight: 'bold',
        lineHeight: 40,
        color: '#333333',
        textAlign: 'right',
    },
    itemsList: {
        backgroundColor: '#eeeeee',
    },
    itemsListContainer: {
        backgroundColor: '#eeeeee',
        paddingVertical: 8,
        marginHorizontal: 8,
    },
});
